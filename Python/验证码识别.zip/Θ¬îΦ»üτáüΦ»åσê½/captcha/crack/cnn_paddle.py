# -*- coding: utf-8 -*-

import paddle.fluid as fluid
import numpy as np
import pandas as pd
import random
import logging
from PIL import Image

logging.basicConfig(level=logging.INFO, format='%(asctime)s: %(message)s')


def data_reader(path, shape, batch_size=128):
    """
    Define the data reader.

    """
    df = pd.read_table(path + 'labels.txt', header=None)
    height, width = shape[1], shape[2]
    for i in range(len(df) / batch_size):
        data = []
        for j in range(batch_size):
            index = random.randint(0, len(df) - 1)
            img = Image.open(path + str(index) + '.png')
            img = img.resize([width, height])
            img = np.multiply(img, 1 / 255.0)
            img = np.asarray(img).transpose([2, 0, 1]).astype('float32')
            label = str(df.ix[index, 0])
            label_0 = np.array(label[0]).astype('int')
            label_1 = np.array(label[1]).astype('int')
            label_2 = np.array(label[2]).astype('int')
            label_3 = np.array(label[3]).astype('int')
            temp = (img, label_0, label_1, label_2, label_3)
            data.append(temp)

        yield data


def cnn_net(x):
    """
    Define the CNN network model.
    This model has 4 cov lays and 4 outputs.
    Each output is for one digit in the image.
    Finally we optimize the 4 output at the same time, each ouput contribute 1/4 the total loss.
    """

    x = fluid.layers.conv2d(input=x, num_filters=32, filter_size=3, act='relu')
    x = fluid.layers.conv2d(input=x, num_filters=32, filter_size=3, act='relu')
    x = fluid.layers.pool2d(input=x, pool_size=2, pool_type='max')
    x = fluid.layers.conv2d(input=x, num_filters=64, filter_size=3, act='relu')
    x = fluid.layers.conv2d(input=x, num_filters=64, filter_size=3, act='relu')
    x = fluid.layers.pool2d(input=x, pool_size=2, pool_type='max')
    x = fluid.layers.dropout(x=x, dropout_prob=0.25)

    yp0 = fluid.layers.fc(input=x, size=10, act='softmax')
    yp1 = fluid.layers.fc(input=x, size=10, act='softmax')
    yp2 = fluid.layers.fc(input=x, size=10, act='softmax')
    yp3 = fluid.layers.fc(input=x, size=10, act='softmax')

    return yp0, yp1, yp2, yp3


def train(model_path, data_path, shape):
    """
    Define the train function.
    """

    x = fluid.layers.data(name='x', shape=shape, dtype='float32')
    y0 = fluid.layers.data(name='y0', shape=[1], dtype='int')
    y1 = fluid.layers.data(name='y1', shape=[1], dtype='int')
    y2 = fluid.layers.data(name='y2', shape=[1], dtype='int')
    y3 = fluid.layers.data(name='y3', shape=[1], dtype='int')

    yp0, yp1, yp2, yp3 = cnn_net(x)
    loss_0 = fluid.layers.cross_entropy(input=yp0, label=y0)
    loss_1 = fluid.layers.cross_entropy(input=yp1, label=y1)
    loss_2 = fluid.layers.cross_entropy(input=yp2, label=y2)
    loss_3 = fluid.layers.cross_entropy(input=yp3, label=y3)
    loss = loss_0 + loss_1 + loss_2 + loss_3
    avg_loss = fluid.layers.mean(loss)

    acc0 = fluid.layers.accuracy(input=yp0, label=y0)
    acc1 = fluid.layers.accuracy(input=yp1, label=y1)
    acc2 = fluid.layers.accuracy(input=yp2, label=y2)
    acc3 = fluid.layers.accuracy(input=yp3, label=y3)

    sgd_optimizer = fluid.optimizer.Adam()
    sgd_optimizer.minimize(avg_loss)

    use_cuda = False
    place = fluid.CUDAPlace(0) if use_cuda else fluid.CPUPlace()
    exe = fluid.Executor(place)

    feeder = fluid.DataFeeder(place=place, feed_list=[x, y0, y1, y2, y3])
    exe.run(fluid.default_startup_program())

    epoch_num = 1000
    for epoch in range(epoch_num):
        total_loss_value = 0
        step = 0
        for data in data_reader(data_path, shape, batch_size=256):
            avg_loss_value, acc0_value, acc1_value, acc2_value, acc3_value = exe.run(
                fluid.default_main_program(), feed=feeder.feed(data), fetch_list=[avg_loss, acc0, acc1, acc2, acc3])
            total_loss_value += avg_loss_value
            flag = acc0_value > 0.99 and acc1_value > 0.99 and acc2_value > 0.99 and acc3_value > 0.99
            if flag or epoch == epoch_num - 1:
                if model_path is not None:
                    fluid.io.save_inference_model(
                        model_path, ['x'], [yp0, yp1, yp2, yp3], exe)
                return
            logging.info("Epoch %d, Step %d, avg loss = %.4f, acc0 = %.2f, acc1 = %.2f, acc2 = %.2f, acc3 = %.2f" %
                         (epoch, step, avg_loss_value, acc0_value, acc1_value, acc2_value, acc3_value))
            step += 1
        logging.info("Epoch %d, total loss = %.4f" % (epoch, total_loss_value))


def infer(model_path, data_path, shape):
    """
    Infer by using provided test data.
    """

    place = fluid.CPUPlace()
    exe = fluid.Executor(place)
    inference_scope = fluid.core.Scope()
    with fluid.scope_guard(inference_scope):
        [inference_program, feed_target_names, fetch_targets] = (
            fluid.io.load_inference_model(model_path, exe))

        test_data = data_reader(data_path, shape, batch_size=1).next()
        test_x = np.array(map(lambda x: x[0], test_data)).astype("float32")
        test_y0 = test_data[0][1]
        test_y1 = test_data[0][2]
        test_y2 = test_data[0][3]
        test_y3 = test_data[0][4]

        results = exe.run(inference_program,
                          feed={feed_target_names[0]: np.array(test_x)},
                          fetch_list=fetch_targets)
        logging.info("infer results: ", results[0].argmax(), results[1].argmax(), results[2].argmax(),
                     results[3].argmax())
        logging.info("ground truth: ", int(test_y0), int(test_y1), int(test_y2), int(test_y3))


def main():
    """
    Main function.
    """
    model_path = "capture.inference.model"
    train_path = '../gen/4_train/'
    test_path = '../gen/4_test/'
    width = 160
    height = 60
    channel = 3
    image_shape = [channel, height, width]
    train(model_path, train_path, image_shape)
    infer(model_path, test_path, image_shape)


if __name__ == "__main__":
    main()
